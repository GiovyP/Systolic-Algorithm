import java.util.Arrays;

public class Processor {
	
  private int a;
  private int pin;
  private int pout; 
  private int xin;
  private int xout; 

  public Processor(int a) {
	this.a = a;
  }
  
  public void setPin(int pin) { 
	this.pin = pin; 
  }
  
  public int getPin() { 
	return pin; 
  } 
  
  public void setXin (int xin) { 
	this.xin = xin; 
  }
  
  public int getXin() { 
	  return xin; 
  }
  
  public int getPout() { 
	  return pout; 
  } 
  
  public int getXout() { 
	  return xout;
  } 
  
  @Override
  public String toString() {
      return "[a=" + a + ", x={ in=" + xin + ", out=" + xout + "}, p={ in=" + pin + ", out=" + pout + "}] " ;
  }
  public static void main(String[] args) {
	  
    int[] coefficients = { 9, 2, -7, 4, 7 };  
    int[] input = { 1, 2, 3, 4, 5 };
    
    int n = coefficients.length;
    int m = input.length; 

    int[] output = new int[input.length];
    Processor[] processors = new Processor[n]; 
    for (int i = 0; i < n; i++) 
      processors[i] = new Processor(coefficients[i]); 
    
    for (int step = 0; step < m + n - 1; step++) {	
      System.out.println("\n\nStep " + step);
      processors[0].setPin(0);
      processors[0].setXin(step < m ? input[step] : 0);
      for (int i = 1; i < n; i++) {
        processors[i].setPin(processors[i - 1].getPin());
        processors[i].setXin(processors[i - 1].getXin());
      }
     
    for ( int i = 0; i < n; i++) {
      if (processors[i].xin != 0) {
    	  processors[i].pout = processors[i].pin * processors[i].xin + processors[i].a;
    	  processors[i].xout = processors[i].xin;
          } else {
    	     processors[i].pout = processors[i].xout = 0;
    	     }
    output[step] = processors[0].pout;
          }
    System.out.println("Result: " + Arrays.toString(output));
      }
    
  }
}
 

